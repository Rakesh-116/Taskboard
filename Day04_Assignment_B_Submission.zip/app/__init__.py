"""Local task management API."""
